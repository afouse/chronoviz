/*==================================================
 *  Common localization strings
 *==================================================
 */

Timeline.strings["fr"] = {
    wikiLinkLabel:  "Discute"
};

